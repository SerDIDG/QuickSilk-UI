/* ******* APPLICATION ******* */

App.LoginBox.prototype.setParams({
    'Com.Tooltip' : {
        'adaptiveX' : true,
        'adaptiveY' : false
    }
});

App.Template.prototype.setParams({
    'stickyFooter' : true
});