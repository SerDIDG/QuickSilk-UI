MagpieUI
=======

Simple and lightweight framework that allows you to build UI quickly as possible.

Attention! Newer versions of MagpieUI library may not be compatible with the previous ones!

Developed with PhpStorm.